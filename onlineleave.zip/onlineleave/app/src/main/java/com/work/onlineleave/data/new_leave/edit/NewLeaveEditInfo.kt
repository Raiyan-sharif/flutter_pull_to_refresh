package com.work.onlineleave.data.new_leave.edit

data class NewLeaveEditInfo(
    val `data`: Data,
    val success: Boolean,
    val total: Int
)
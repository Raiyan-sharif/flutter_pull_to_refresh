package com.work.onlineleave.data.applyto

data class Data(
    val authcode: String,
    val authname: String
)
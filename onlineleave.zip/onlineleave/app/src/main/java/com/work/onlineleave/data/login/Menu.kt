package com.work.onlineleave.data.login

data class Menu(
    val ajax: String,
    val funcname: String,
    val iconcls: String,
    val id: String,
    val menucode: String,
    val parent_id: String,
    val published: String,
    val showcount: String,
    val sort_id: String,
    val title: String
)
package com.work.onlineleave.data.my_approval

data class Data(
    val appcode: String,
    val appname: String,
    val leaveappdate: String,
    val leaveappdays: String,
    val leaveappfrom: String,
    val leaveappto: String,
    val leavefor: String,
    val reason: String,
    val leaverefno: String,
    val status: String
)
package com.work.onlineleave.data.my_approval

data class MyApproval(
    val `data`: List<Data>,
    val success: Boolean,
    val total: String
)
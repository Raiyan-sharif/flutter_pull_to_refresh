package com.work.onlineleave.data.new_leave

data class Message(
    val note: String
)
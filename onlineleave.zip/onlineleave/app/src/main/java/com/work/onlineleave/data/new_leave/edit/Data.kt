package com.work.onlineleave.data.new_leave.edit

data class Data(
    val authcode: String,
    val empname: String,
    val lappfrom: String,
    val lappto: String,
    val leaveappdate: String,
    val leaveappdays: String,
    val leaveappfrom: String,
    val leaveappto: String,
    val leavedetails: String,
    val leavefor: String,
    val leaverefno: String,
    val lfa: String,
    val reason: String
)
package com.work.onlineleave.data.my_leave

data class Data(
    val empcode: String,
    val leaveappdate: String,
    val leaveappdays: String,
    val leaveappfrom: String,
    val leaveappto: String,
    val leavefor: String,
    val leaverefno: String,
    val lfa: String,
    val status: String,
    val today: String
)
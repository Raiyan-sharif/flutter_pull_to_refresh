package com.work.onlineleave.data.my_approval.approve

data class Message(
    val note: String
)
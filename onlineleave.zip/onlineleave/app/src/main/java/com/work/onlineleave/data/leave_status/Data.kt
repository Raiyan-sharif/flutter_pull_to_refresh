package com.work.onlineleave.data.leave_status

data class Data(
    val INDICATOR: String,
    val PRIVILEGE_LEAVE: String,
    val SICK_LEAVE: String
)
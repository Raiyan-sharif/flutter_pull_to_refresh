package com.work.onlineleave.data.applyto

data class ApplyTo(
    val `data`: List<Data>,
    val success: Boolean,
    val total: Int
)
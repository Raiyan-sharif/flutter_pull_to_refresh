package com.work.onlineleave.view.dashboard

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupWithNavController
import com.google.android.material.button.MaterialButton
import com.work.onlineleave.R
import com.work.onlineleave.core.BaseActivity
import com.work.onlineleave.view.login.LoginActivity
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : BaseActivity() {

    public var logoutBtn: MaterialButton? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val navController = findNavController(R.id.nav_host_fragment)
        val appBarConfiguration = AppBarConfiguration(navController.graph)
        toolbar.setupWithNavController(navController, appBarConfiguration)

        logoutBtn = toolbar.findViewById(R.id.logout_btn)

        logoutBtn?.setOnClickListener {

            logout()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }
}

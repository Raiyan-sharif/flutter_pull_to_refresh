package com.work.onlineleave.util

import java.text.SimpleDateFormat

class AppUtil {

    companion object {

        public fun formatDateToApiFormat(date: String): String {

            val sdf = SimpleDateFormat("yyyy-MM-dd")
            val sdf2 = SimpleDateFormat("dd/MM/yyyy")
            return sdf2.format(sdf.parse(date))
        }

        public fun formatDateToApiYearMonthDateFormat(date: String): String {

            val sdf = SimpleDateFormat("dd/MM/yyyy")
            val sdf2 = SimpleDateFormat("yyyy-MM-dd")
            return sdf2.format(sdf.parse(date))
        }
    }
}
package com.work.onlineleave.app_update

import android.app.Activity
import android.util.Log

import androidx.lifecycle.MutableLiveData
import com.work.onlineleave.util.ProgressDialogWithMessage
import kotlinx.coroutines.*
import java.io.*
import java.lang.Exception
import java.net.URL

/**
 * copied from ACI FPM
 */

class DownloadUpdate(var activity: Activity) {

    companion object {
        const val APK_NAME = "online_leave.apk"
        const val NAME = "app_update_name"
        const val INSTALL_REQUEST_CODE = 9889
    }

    private var totalFileSize: Double = 0.0
    private val TAG = "APP_UPDATE"

    private var downloadJob: Job? = null

    private val progressDialogWithMessage: ProgressDialogWithMessage by lazy {
        ProgressDialogWithMessage(activity)
    }

    public var downloadState: MutableLiveData<DownloadModel> = MutableLiveData()

    public fun initDownload(downloadUrl: String) {
        progressDialogWithMessage.setMessage("Downloading update..")
        progressDialogWithMessage.show()

        try {
            downloadJob = CoroutineScope(Dispatchers.IO).launch {

                Log.d(TAG, "initDownload thread-> ${Thread.currentThread().name}")

                val url = URL(downloadUrl)
                val connection = url.openConnection()
                connection.connect()

                // this will be useful so that you can show a typical 0-100% progress bar
                val fileLength = connection.contentLength

                // download the file
                val input = BufferedInputStream(connection.getInputStream())
                val output = FileOutputStream(File(activity.cacheDir, APK_NAME))
                val data = ByteArray(1024)
                var total: Long = 0
                var count: Int
                var lastProgress: Int = 0

                val download = DownloadModel()
                totalFileSize = (fileLength / (1024.0 * 1024.0))
                download.totalFileSize = totalFileSize.toInt()

                while (true) {
                    count = input.read(data)

                    if (count == -1) {
                        break
                    }
                    total += count.toLong()

                    download.currentFileSize = (total / 1024).toDouble()
                    download.progress = ((total * 100) / fileLength).toInt()

                    Log.e(TAG, "DownloadProgress : " + download.progress)
                    if (download.progress != lastProgress) {
                        lastProgress = download.progress

                        withContext(Dispatchers.Main) {
                            progressDialogWithMessage.setMessage(
                                "Downloading update.. \n ${download.currentFileSize} KB/ ${
                                    String.format(
                                        "%.2f",
                                        totalFileSize
                                    )
                                } MB"
                            )
                            if (download.progress != 100) {
                                downloadState.value = download
                            }
                        }
                    }

                    output.write(data, 0, count)
                }

                withContext(Dispatchers.Main) {
                    onDownloadComplete()
                }

                output.flush()
                output.close()
                input.close()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            progressDialogWithMessage.dismiss()
        }
    }

    private fun onDownloadComplete() {
        Log.d(TAG, "onDownloadComplete thread-> ${Thread.currentThread().name}")
        val download = DownloadModel()
        download.progress = 100
        downloadState.value = download
        dismissDownload()
    }

    public fun dismissDownload() {
        Log.d(TAG, "dismissDownload")
        downloadJob?.cancel()
        progressDialogWithMessage.dismiss()
    }
}
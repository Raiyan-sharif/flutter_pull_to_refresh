package com.work.onlineleave.data

data class LoginPostItem(val username: String, val password: String)



// orders list response

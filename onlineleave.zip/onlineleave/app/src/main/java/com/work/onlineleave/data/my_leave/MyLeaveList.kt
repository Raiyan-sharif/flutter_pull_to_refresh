package com.work.onlineleave.data.my_leave

data class MyLeaveList(
    val `data`: ArrayList<Data>,
    val success: Boolean
)
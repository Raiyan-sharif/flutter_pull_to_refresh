package com.work.onlineleave.util

import android.app.ActionBar
import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.Point
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.widget.TextView
import com.work.onlineleave.R


class ProgressDialogWithMessage {

    private lateinit var dialog: Dialog
    private var messageTv: TextView? = null
    private var activity: Activity? = null

    constructor(activity: Activity){

        val display = activity.windowManager.defaultDisplay
        val size = Point()
        display.getSize(size)
        val width = size.x

        this.activity = activity
        dialog = Dialog(activity)

        val view = LayoutInflater.from(activity).inflate(R.layout.progress_dialog_with_message, null)
        messageTv = view.findViewById(R.id.progressbar_message_tv)

        dialog.setContentView(view)
        dialog.setCancelable(false)

        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window!!.setLayout(width - 150, ActionBar.LayoutParams.WRAP_CONTENT)
    }

    fun setMessage(message: String?) {
        messageTv?.text = message
    }

    public fun show(){
        if(dialog != null && !dialog.isShowing && activity != null && !activity!!.isFinishing){
            dialog.show()
        }
    }

    public fun dismiss() {
        if (dialog != null && dialog.isShowing) {
            dialog.dismiss()
        }
    }

    public fun isShowing(): Boolean{
        if(dialog != null) {
            return dialog.isShowing
        }
        return false
    }

}
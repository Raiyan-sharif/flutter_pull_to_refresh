package com.work.onlineleave.core

import android.content.SharedPreferences
import android.os.Bundle
import androidx.fragment.app.Fragment
import com.work.onlineleave.util.ProgressDialog

open class BaseFragment: Fragment() {

    protected var sharedPref: SharedPreferences? = null
    protected var progressDialog: ProgressDialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sharedPref = requireActivity().getSharedPreferences("ONLINE_LEAVE", 0)
    }

    protected fun showProgressDialog() {
        if (progressDialog == null) {
            progressDialog = ProgressDialog(requireContext())
        }

        if (!progressDialog!!.isShowing) {
            progressDialog!!.show()
        }
    }

    protected fun dismissProgressDialog() {
        if (progressDialog != null && progressDialog!!.isShowing) {
            progressDialog!!.dismiss()
        }
    }

}
package com.work.onlineleave.data.govt_holiday

data class GovtHolidayItem(
    val appto: String,
    val hdate: String,
    val highlight: String,
    val holidaydate: String,
    val holidayfor: String,
    val holidayid: String,
    val remarks: String
)
package com.work.onlineleave.data.leavetype

data class Data(
    val details: String,
    val leavefor: String
)
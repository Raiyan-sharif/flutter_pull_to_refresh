package com.work.onlineleave.data.my_approval.approve

data class CommonResponse(
    val message: Message,
    val success: Boolean,
    val total: Int
)
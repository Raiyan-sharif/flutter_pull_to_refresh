package com.work.onlineleave.app_update

import java.io.Serializable

/**
 * copied from ACI FPM
 */

data class DownloadModel(
    var progress: Int = 0,
    var currentFileSize: Double = 0.0,
    var totalFileSize: Int = 0
) : Serializable
package com.work.onlineleave.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.LinearLayout
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.work.onlineleave.R
import com.work.onlineleave.data.my_approval.Data
import com.work.onlineleave.data.my_approval.MyApproval


class MyApprovalAdapter(private var myApproval: MyApproval, private var context: Context) :
    RecyclerView.Adapter<MyApprovalAdapter.TestViewHolder>() {
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MyApprovalAdapter.TestViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.my_approval_adapter_item, parent, false)
        return TestViewHolder(view)
    }

    override fun getItemCount(): Int {
        return myApproval.data.size
    }

    private var listener: OnClickListener? = null

    fun setListener(listener: OnClickListener) {
        this.listener = listener
    }

    interface OnClickListener {
        fun onApproveButtonClick(item: Data)
        fun onRefuseButtonClick(item: Data)
        fun onCancelButtonClick(item: Data)
        fun onCardClick(item: Data)
    }

    override fun onBindViewHolder(holder: MyApprovalAdapter.TestViewHolder, position: Int) {
        setAnimation(holder.cardItem);

        holder.tvRefNumber.text = myApproval.data[position].leaverefno
        holder.tvAppName.text = myApproval.data[position].appname
        holder.tvAppDate.text = myApproval.data[position].leaveappdate
        holder.tvApDateFrom.text = myApproval.data[position].leaveappfrom
        holder.tvDateTo.text = myApproval.data[position].leaveappto
        holder.tvDays.text = myApproval.data[position].leaveappdays
        holder.tvStatus.text = myApproval.data[position].status

        holder.entryTypeTv.text = myApproval.data[position].leavefor
        holder.detailsTv.text = myApproval.data[position].reason

        when (myApproval.data[position].status) {
            "Awaiting" -> {
                holder.approveBtn.visibility = View.VISIBLE
                holder.refuseBtn.visibility = View.VISIBLE
                holder.cancelBtn.visibility = View.GONE
                holder.llButtons.visibility = View.VISIBLE
            }
            "Refused", "Posted" -> {
                holder.llButtons.visibility = View.GONE
            }
            "Granted" -> {
                holder.approveBtn.visibility = View.GONE
                holder.refuseBtn.visibility = View.GONE
                holder.cancelBtn.visibility = View.VISIBLE
                holder.llButtons.visibility = View.VISIBLE
            }
        }

        holder.cardItem.setOnClickListener {

            listener?.onCardClick(myApproval.data[position])
        }

        holder.approveBtn.setOnClickListener {
            listener?.onApproveButtonClick(myApproval.data[position])
        }

        holder.refuseBtn.setOnClickListener {
            listener?.onRefuseButtonClick(myApproval.data[position])
        }

        holder.cancelBtn.setOnClickListener {
            listener?.onCancelButtonClick(myApproval.data[position])
        }
    }

    override fun onViewDetachedFromWindow(holder: TestViewHolder) {
        super.onViewDetachedFromWindow(holder)
        holder.itemView.clearAnimation()

    }

    class TestViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        val tvRefNumber: TextView = view.findViewById(R.id.tvRefNumber)
        val tvAppName: TextView = view.findViewById(R.id.tvAppName)
        val tvAppDate: TextView = view.findViewById(R.id.tvAppDate)
        val tvApDateFrom: TextView = view.findViewById(R.id.tvApDateFrom)
        val tvDateTo: TextView = view.findViewById(R.id.tvDateTo)
        val tvDays: TextView = view.findViewById(R.id.tvDays)
        val tvStatus: TextView = view.findViewById(R.id.tvStatus)

        val approveBtn: TextView = view.findViewById(R.id.approve_btn)
        val refuseBtn: TextView = view.findViewById(R.id.refuse_btn)
        val cancelBtn: TextView = view.findViewById(R.id.cancel_btn)

        val cardItem: CardView = view.findViewById(R.id.cardItem)
        val llButtons: LinearLayout = view.findViewById(R.id.llButtons)

        val entryTypeTv: TextView = view.findViewById(R.id.entry_type_tv)
        val detailsTv: TextView = view.findViewById(R.id.details_tv)
    }


    private fun setAnimation(viewToAnimate: View) {
        // If the bound view wasn't previously displayed on screen, it's animated
        val animation: Animation =
            AnimationUtils.loadAnimation(context, android.R.anim.fade_in)
        viewToAnimate.startAnimation(animation)
    }
}
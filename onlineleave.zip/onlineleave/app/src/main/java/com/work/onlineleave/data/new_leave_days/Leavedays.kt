package com.work.onlineleave.data.new_leave_days

data class Leavedays(
    val leaveappdays: Int,
    val success: Boolean
)
package com.work.onlineleave.data.my_leave.delete

data class MyLeaveDelete(
    val success: Boolean,
    val total: Int
)
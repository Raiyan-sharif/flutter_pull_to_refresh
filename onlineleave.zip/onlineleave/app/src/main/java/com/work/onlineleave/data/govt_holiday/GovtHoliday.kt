package com.work.onlineleave.data.govt_holiday

class GovtHoliday : ArrayList<GovtHolidayItem>()